document.addEventListener("DOMContentLoaded", function () {
  "use strict";

  const MAX_ROWS = 50000;
  const PREVIEW_ROWS = 10;
  const $ = (id) => document.getElementById(id);

  if (typeof proj4 === "undefined") {
    document.body.innerHTML = "<p>The transformation library could not be loaded.</p>";
    return;
  }
  if (typeof XLSX === "undefined") {
    document.body.innerHTML = "<p>The spreadsheet library could not be loaded.</p>";
    return;
  }

  proj4.defs(
    "EPSG:2039",
    "+proj=tmerc +lat_0=31.7343936111111 +lon_0=35.2045169444444 " +
    "+k=1.0000067 +x_0=219529.584 +y_0=626907.39 +ellps=GRS80 " +
    "+towgs84=23.772,17.49,17.859,-0.3132,-1.85274,1.67299,-5.4262 " +
    "+units=m +no_defs +type=crs"
  );

  proj4.defs(
    "EPSG:28193",
    "+proj=cass +lat_0=31.7340969444444 +lon_0=35.2120805555556 " +
    "+x_0=170251.555 +y_0=1126867.909 +a=6378300.789 +b=6356566.435 " +
    "+towgs84=-275.7224,94.7824,340.8944,-8.001,-4.42,-11.821,1 " +
    "+units=m +no_defs +type=crs"
  );

  const ISRAEL_AREA = { west: 34.17, south: 29.45, east: 35.69, north: 33.28 };

  const CRS_RULES = {
    "EPSG:4326": {
      label: "WGS 84",
      type: "geographic",
      xName: "Longitude",
      yName: "Latitude",
      xMin: -180, xMax: 180, yMin: -90, yMax: 90,
      help: "Expected: longitude −180° to 180°; latitude −90° to 90°."
    },
    "EPSG:2039": {
      label: "Israeli TM Grid (ITM)",
      type: "projected",
      xName: "Easting",
      yName: "Northing",
      xMin: 119097.33, xMax: 266563.36,
      yMin: 373609.64, yMax: 798747.07,
      area: ISRAEL_AREA,
      help: "Expected: Easting 119,097–266,563 m; Northing 373,610–798,747 m."
    },
    "EPSG:28193": {
      label: "Israeli Old Grid (ICS)",
      type: "projected",
      xName: "Easting",
      yName: "Northing",
      xMin: 69099.91, xMax: 216561.80,
      yMin: 873606.74, yMax: 1298746.25,
      area: ISRAEL_AREA,
      help: "Expected: Easting 69,100–216,562 m; Northing 873,607–1,298,746 m."
    }
  };

  function mountCrsControls(containerId, prefix) {
    const container = $(containerId);
    const fragment = $("crs-controls-template").content.cloneNode(true);
    container.appendChild(fragment);

    const q = (role) => container.querySelector(`[data-role="${role}"]`);
    const controls = {
      prefix,
      sourceCrs: q("source-crs"),
      targetCrs: q("target-crs"),
      sourceUtmOptions: q("source-utm-options"),
      targetUtmOptions: q("target-utm-options"),
      sourceZone: q("source-zone"),
      targetZone: q("target-zone"),
      sourceHemisphere: q("source-hemisphere"),
      targetHemisphere: q("target-hemisphere"),
      autoTargetUtm: q("auto-target-utm"),
      sourceZoneHelp: q("source-zone-help"),
      targetZoneHelp: q("target-zone-help"),
      sourceRangeHelp: q("source-range-help"),
      swap: q("swap")
    };

    fillZones(controls.sourceZone, 36);
    fillZones(controls.targetZone, 36);

    [
      controls.sourceCrs, controls.targetCrs,
      controls.sourceZone, controls.targetZone,
      controls.sourceHemisphere, controls.targetHemisphere,
      controls.autoTargetUtm
    ].forEach((element) => {
      element.addEventListener("change", () => {
        updateCrsControls(controls);
        if (prefix === "single") updateSingleInputLabels();
      });
    });

    controls.swap.addEventListener("click", () => {
      const oldCrs = controls.sourceCrs.value;
      controls.sourceCrs.value = controls.targetCrs.value;
      controls.targetCrs.value = oldCrs;

      const oldZone = controls.sourceZone.value;
      controls.sourceZone.value = controls.targetZone.value;
      controls.targetZone.value = oldZone;

      const oldHemisphere = controls.sourceHemisphere.value;
      controls.sourceHemisphere.value = controls.targetHemisphere.value;
      controls.targetHemisphere.value = oldHemisphere;

      updateCrsControls(controls);
      if (prefix === "single") updateSingleInputLabels();
    });

    updateCrsControls(controls);
    return controls;
  }

  function fillZones(select, selectedZone) {
    select.innerHTML = "";
    for (let zone = 1; zone <= 60; zone += 1) {
      const option = document.createElement("option");
      option.value = String(zone);
      option.textContent = String(zone);
      option.selected = zone === selectedZone;
      select.appendChild(option);
    }
  }

  function updateCrsControls(controls) {
    const sourceIsUtm = controls.sourceCrs.value === "UTM";
    const targetIsUtm = controls.targetCrs.value === "UTM";
    controls.sourceUtmOptions.classList.toggle("is-hidden", !sourceIsUtm);
    controls.targetUtmOptions.classList.toggle("is-hidden", !targetIsUtm);
    updateZoneHelp(controls.sourceZoneHelp, Number(controls.sourceZone.value));
    updateZoneHelp(controls.targetZoneHelp, Number(controls.targetZone.value));

    controls.sourceRangeHelp.textContent = sourceIsUtm
      ? "Expected: Easting approximately 100,000–900,000 m; Northing 0–10,000,000 m."
      : CRS_RULES[controls.sourceCrs.value].help;
  }

  function updateZoneHelp(element, zone) {
    const west = -180 + (zone - 1) * 6;
    element.textContent = `Standard zone ${zone}: ${west}° to ${west + 6}° longitude.`;
  }

  function parseCoordinate(rawValue) {
    if (typeof rawValue === "number") {
      if (!Number.isFinite(rawValue)) throw new Error("Coordinate is not a finite number.");
      return rawValue;
    }
    if (rawValue === null || rawValue === undefined || String(rawValue).trim() === "") {
      throw new Error("A coordinate value is missing.");
    }
    const cleaned = String(rawValue).trim().replace(/\s+/g, "").replace(",", ".");
    const value = Number(cleaned);
    if (!Number.isFinite(value)) throw new Error(`"${rawValue}" is not a valid number.`);
    return value;
  }

  function within(value, min, max, tolerance = 0) {
    return value >= min - tolerance && value <= max + tolerance;
  }

  function normaliseLongitude(longitude) {
    if (longitude === 180) return 180;
    return ((longitude + 180) % 360 + 360) % 360 - 180;
  }

  function standardUtmZone(longitude) {
    const lon = normaliseLongitude(longitude);
    if (lon === 180) return 60;
    return Math.floor((lon + 180) / 6) + 1;
  }

  function utmZoneForLocation(longitude, latitude) {
    const lon = normaliseLongitude(longitude);
    if (latitude >= 56 && latitude < 64 && lon >= 3 && lon < 12) return 32;
    if (latitude >= 72 && latitude < 84) {
      if (lon >= 0 && lon < 9) return 31;
      if (lon >= 9 && lon < 21) return 33;
      if (lon >= 21 && lon < 33) return 35;
      if (lon >= 33 && lon < 42) return 37;
    }
    return standardUtmZone(lon);
  }

  function hemisphereForLatitude(latitude) {
    return latitude >= 0 ? "N" : "S";
  }

  function createUtmDefinition(zone, hemisphere) {
    const code = `CUSTOM:UTM${zone}${hemisphere}`;
    const southFlag = hemisphere === "S" ? " +south" : "";
    proj4.defs(
      code,
      `+proj=utm +zone=${zone}${southFlag} +datum=WGS84 +units=m +no_defs +type=crs`
    );
    return code;
  }

  function resolveCrs(controls, side, geographicLocation = null) {
    const sourceSide = side === "source";
    const selected = sourceSide ? controls.sourceCrs.value : controls.targetCrs.value;

    if (selected !== "UTM") {
      return {
        key: selected,
        code: selected,
        type: CRS_RULES[selected].type,
        label: selected === "EPSG:4326"
          ? "WGS 84 — EPSG:4326"
          : selected === "EPSG:2039"
            ? "Israeli TM Grid — EPSG:2039"
            : "Israeli Old Grid — EPSG:28193"
      };
    }

    let zone = Number(sourceSide ? controls.sourceZone.value : controls.targetZone.value);
    let hemisphere = sourceSide
      ? controls.sourceHemisphere.value
      : controls.targetHemisphere.value;

    if (
      !sourceSide &&
      controls.autoTargetUtm.checked &&
      geographicLocation
    ) {
      zone = utmZoneForLocation(geographicLocation[0], geographicLocation[1]);
      hemisphere = hemisphereForLatitude(geographicLocation[1]);
    }

    if (!Number.isInteger(zone) || zone < 1 || zone > 60) {
      throw new Error("UTM zone must be a whole number from 1 to 60.");
    }

    return {
      key: "UTM",
      code: createUtmDefinition(zone, hemisphere),
      type: "projected",
      zone,
      hemisphere,
      label: `WGS 84 / UTM zone ${zone}${hemisphere}`
    };
  }

  function isWithinArea(longitude, latitude, area, tolerance = 0.02) {
    return (
      within(longitude, area.west, area.east, tolerance) &&
      within(latitude, area.south, area.north, tolerance)
    );
  }

  function validateGeographic(longitude, latitude) {
    if (!within(longitude, -180, 180)) throw new Error("Longitude must be between −180° and 180°.");
    if (!within(latitude, -90, 90)) throw new Error("Latitude must be between −90° and 90°.");
  }

  function validateProjectedInput(x, y, crsKey) {
    const rule = CRS_RULES[crsKey];
    if (within(x, rule.xMin, rule.xMax) && within(y, rule.yMin, rule.yMax)) return;

    if (within(y, rule.xMin, rule.xMax) && within(x, rule.yMin, rule.yMax)) {
      throw new Error(`${rule.label}: values appear reversed; enter Easting first and Northing second.`);
    }

    throw new Error(
      `${rule.label}: coordinate outside expected bounds ` +
      `(Easting ${Math.round(rule.xMin).toLocaleString()}–${Math.round(rule.xMax).toLocaleString()}, ` +
      `Northing ${Math.round(rule.yMin).toLocaleString()}–${Math.round(rule.yMax).toLocaleString()}).`
    );
  }

  function validateUtmNumeric(easting, northing) {
    if (within(easting, 100000, 900000) && within(northing, 0, 10000000)) return;
    if (within(northing, 100000, 900000) && within(easting, 0, 10000000)) {
      throw new Error("UTM values may be reversed; enter Easting first and Northing second.");
    }
    throw new Error("Implausible UTM coordinate; expected Easting 100,000–900,000 m and Northing 0–10,000,000 m.");
  }

  function validateSourceInput(source, x, y) {
    if (source.key === "EPSG:4326") validateGeographic(x, y);
    else if (source.key === "EPSG:2039" || source.key === "EPSG:28193") validateProjectedInput(x, y, source.key);
    else validateUtmNumeric(x, y);
  }

  function toGeographic(source, x, y) {
    if (source.key === "EPSG:4326") return [x, y];
    const result = proj4(source.code, "EPSG:4326", [x, y]);
    if (!result || !Number.isFinite(result[0]) || !Number.isFinite(result[1])) {
      throw new Error("Input could not be resolved to a valid geographic location.");
    }
    validateGeographic(result[0], result[1]);
    return result;
  }

  function validateSourceArea(source, longitude, latitude) {
    if (source.key === "EPSG:2039" || source.key === "EPSG:28193") {
      const rule = CRS_RULES[source.key];
      if (!isWithinArea(longitude, latitude, rule.area)) {
        throw new Error(`${rule.label}: coordinate resolves outside its area of use.`);
      }
    }

    if (source.key === "UTM") {
      if (latitude < -80 || latitude > 84) throw new Error("UTM is normally used only between 80°S and 84°N.");
      const expectedZone = utmZoneForLocation(longitude, latitude);
      const expectedHemisphere = hemisphereForLatitude(latitude);
      if (source.zone !== expectedZone || source.hemisphere !== expectedHemisphere) {
        throw new Error(
          `Source UTM coordinate resolves to zone ${expectedZone}${expectedHemisphere}, ` +
          `not declared zone ${source.zone}${source.hemisphere}.`
        );
      }
    }
  }

  function validateTargetArea(target, longitude, latitude) {
    if (target.key === "EPSG:2039" || target.key === "EPSG:28193") {
      if (!isWithinArea(longitude, latitude, CRS_RULES[target.key].area)) {
        throw new Error(`${CRS_RULES[target.key].label}: location is outside the CRS area of use.`);
      }
    }
    if (target.key === "UTM" && (latitude < -80 || latitude > 84)) {
      throw new Error("UTM is normally used only between 80°S and 84°N.");
    }
  }

  function validateManualTargetUtm(controls, target, longitude, latitude) {
    if (target.key !== "UTM" || controls.autoTargetUtm.checked) return;
    const expectedZone = utmZoneForLocation(longitude, latitude);
    const expectedHemisphere = hemisphereForLatitude(latitude);
    if (target.zone !== expectedZone || target.hemisphere !== expectedHemisphere) {
      throw new Error(
        `Location belongs to UTM zone ${expectedZone}${expectedHemisphere}, ` +
        `not ${target.zone}${target.hemisphere}.`
      );
    }
  }

  function validateRoundTrip(source, target, input, output) {
    const returned = proj4(target.code, source.code, output);
    const tolerance = source.type === "geographic" ? 1e-7 : 0.05;
    if (
      !returned ||
      !Number.isFinite(returned[0]) ||
      !Number.isFinite(returned[1]) ||
      Math.abs(returned[0] - input[0]) > tolerance ||
      Math.abs(returned[1] - input[1]) > tolerance
    ) {
      throw new Error("Transformation failed its round-trip consistency check.");
    }
  }

  function convertCoordinate(controls, rawX, rawY) {
    const x = parseCoordinate(rawX);
    const y = parseCoordinate(rawY);
    const source = resolveCrs(controls, "source");
    validateSourceInput(source, x, y);

    const geographic = toGeographic(source, x, y);
    validateSourceArea(source, geographic[0], geographic[1]);

    const target = resolveCrs(controls, "target", geographic);
    validateTargetArea(target, geographic[0], geographic[1]);
    validateManualTargetUtm(controls, target, geographic[0], geographic[1]);

    if (source.code === target.code) throw new Error("Source and target coordinate systems are identical.");

    const converted = proj4(source.code, target.code, [x, y]);
    if (!converted || !Number.isFinite(converted[0]) || !Number.isFinite(converted[1])) {
      throw new Error("Transformation did not return a valid coordinate.");
    }

    if (target.key === "EPSG:2039" || target.key === "EPSG:28193") {
      validateProjectedInput(converted[0], converted[1], target.key);
    } else if (target.key === "UTM") {
      validateUtmNumeric(converted[0], converted[1]);
    }

    validateRoundTrip(source, target, [x, y], converted);

    return {
      x: converted[0],
      y: converted[1],
      sourceLabel: source.label,
      targetLabel: target.label,
      targetZone: target.key === "UTM" ? target.zone : "",
      targetHemisphere: target.key === "UTM" ? target.hemisphere : "",
      targetGeographic: target.key === "EPSG:4326"
    };
  }

  const singleControls = mountCrsControls("single-crs-controls", "single");
  const batchControls = mountCrsControls("batch-crs-controls", "batch");

  function updateSingleInputLabels() {
    const geographic = singleControls.sourceCrs.value === "EPSG:4326";
    $("single-x-label").textContent = geographic ? "Longitude / X" : "Easting / X";
    $("single-y-label").textContent = geographic ? "Latitude / Y" : "Northing / Y";
    $("single-x").placeholder = geographic ? "35.2" : "200000";
    $("single-y").placeholder = geographic ? "32.5" : "650000";
    $("single-result").classList.add("is-hidden");
    showMessage($("single-message"), "");
  }

  function showMessage(element, text, type = "") {
    element.textContent = text;
    element.className = `message${type ? ` ${type}` : ""}`;
  }

  $("single-convert").addEventListener("click", () => {
    $("single-result").classList.add("is-hidden");
    showMessage($("single-message"), "");
    try {
      const output = convertCoordinate(singleControls, $("single-x").value, $("single-y").value);
      $("single-result-crs").textContent = output.targetLabel;
      $("single-result-x-label").textContent = output.targetGeographic ? "Longitude" : "Easting";
      $("single-result-y-label").textContent = output.targetGeographic ? "Latitude" : "Northing";
      $("single-result-x").textContent = output.targetGeographic ? output.x.toFixed(7) : output.x.toFixed(3);
      $("single-result-y").textContent = output.targetGeographic ? output.y.toFixed(7) : output.y.toFixed(3);
      $("single-result").classList.remove("is-hidden");
      showMessage($("single-message"), "The coordinate was converted and validated successfully.", "success");
    } catch (error) {
      showMessage($("single-message"), error.message || "Conversion failed.", "error");
    }
  });

  $("single-copy").addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(
        `${$("single-result-x").textContent}, ${$("single-result-y").textContent}`
      );
      showMessage($("single-message"), "The converted coordinate was copied.", "success");
    } catch (_) {
      showMessage($("single-message"), "Copying failed. Copy the values manually.", "error");
    }
  });

  [$("single-x"), $("single-y")].forEach((input) => {
    input.addEventListener("keydown", (event) => {
      if (event.key === "Enter") $("single-convert").click();
    });
  });
  updateSingleInputLabels();

  function activateTab(mode) {
    const single = mode === "single";
    $("single-tab").classList.toggle("is-active", single);
    $("batch-tab").classList.toggle("is-active", !single);
    $("single-tab").setAttribute("aria-selected", String(single));
    $("batch-tab").setAttribute("aria-selected", String(!single));
    $("single-panel").classList.toggle("is-hidden", !single);
    $("batch-panel").classList.toggle("is-hidden", single);
  }

  $("single-tab").addEventListener("click", () => activateTab("single"));
  $("batch-tab").addEventListener("click", () => activateTab("batch"));

  let workbook = null;
  let sheetMatrix = [];
  let outputMatrix = null;
  let errorMatrix = null;
  let inputFileBaseName = "coordinates";

  function resetBatchAfterFile() {
    $("batch-setup").classList.add("is-hidden");
    $("batch-crs-section").classList.add("is-hidden");
    $("batch-preview-section").classList.add("is-hidden");
    $("batch-results").classList.add("is-hidden");
    showMessage($("batch-message"), "");
    outputMatrix = null;
    errorMatrix = null;
  }

  $("batch-file").addEventListener("change", async (event) => {
    resetBatchAfterFile();
    const file = event.target.files[0];
    if (!file) return;

    if (file.size > 15 * 1024 * 1024) {
      showMessage($("batch-message"), "The file is larger than 15 MB.", "error");
      return;
    }

    inputFileBaseName = file.name.replace(/\.[^.]+$/, "") || "coordinates";

    try {
      const data = await file.arrayBuffer();
      workbook = XLSX.read(data, { type: "array", cellDates: true, dense: true });
      if (!workbook.SheetNames.length) throw new Error("The file contains no worksheets.");

      $("batch-sheet").innerHTML = "";
      workbook.SheetNames.forEach((name) => {
        const option = document.createElement("option");
        option.value = name;
        option.textContent = name;
        $("batch-sheet").appendChild(option);
      });

      $("batch-setup").classList.remove("is-hidden");
      $("batch-crs-section").classList.remove("is-hidden");
      $("batch-preview-section").classList.remove("is-hidden");
      loadSelectedSheet();
    } catch (error) {
      showMessage($("batch-message"), error.message || "The spreadsheet could not be read.", "error");
    }
  });

  function loadSelectedSheet() {
    if (!workbook) return;
    const sheet = workbook.Sheets[$("batch-sheet").value];
    sheetMatrix = XLSX.utils.sheet_to_json(sheet, {
      header: 1,
      raw: true,
      defval: null,
      blankrows: false
    });

    populateColumnSelectors();
    renderPreview();
  }

  function makeHeaderLabel(value, index) {
    const text = value === null || value === undefined || String(value).trim() === ""
      ? `Column ${index + 1}`
      : String(value).trim();
    return `${text} [${columnLetter(index)}]`;
  }

  function columnLetter(index) {
    let value = index + 1;
    let letters = "";
    while (value > 0) {
      const remainder = (value - 1) % 26;
      letters = String.fromCharCode(65 + remainder) + letters;
      value = Math.floor((value - 1) / 26);
    }
    return letters;
  }

  function populateColumnSelectors() {
    const headerIndex = Number($("batch-header-row").value);
    const header = sheetMatrix[headerIndex] || [];
    const maxColumns = Math.max(header.length, ...sheetMatrix.slice(0, 20).map((row) => row.length), 0);

    [$("batch-x-column"), $("batch-y-column")].forEach((select) => {
      select.innerHTML = "";
      for (let index = 0; index < maxColumns; index += 1) {
        const option = document.createElement("option");
        option.value = String(index);
        option.textContent = makeHeaderLabel(header[index], index);
        select.appendChild(option);
      }
    });

    const lowerHeaders = header.map((value) => String(value ?? "").trim().toLowerCase());
    const xIndex = lowerHeaders.findIndex((value) =>
      ["x", "longitude", "lon", "long", "easting", "east"].includes(value)
    );
    const yIndex = lowerHeaders.findIndex((value) =>
      ["y", "latitude", "lat", "northing", "north"].includes(value)
    );

    $("batch-x-column").value = String(xIndex >= 0 ? xIndex : 0);
    $("batch-y-column").value = String(yIndex >= 0 ? yIndex : Math.min(1, Math.max(0, maxColumns - 1)));
  }

  function renderPreview() {
    const headerIndex = Number($("batch-header-row").value);
    const header = sheetMatrix[headerIndex] || [];
    const rows = sheetMatrix.slice(headerIndex + 1).filter((row) =>
      row.some((value) => value !== null && value !== undefined && String(value).trim() !== "")
    );

    const maxColumns = Math.min(
      Math.max(header.length, ...rows.slice(0, PREVIEW_ROWS).map((row) => row.length), 0),
      12
    );

    const headRow = document.createElement("tr");
    for (let index = 0; index < maxColumns; index += 1) {
      const th = document.createElement("th");
      th.textContent = makeHeaderLabel(header[index], index);
      headRow.appendChild(th);
    }
    $("batch-preview-table").querySelector("thead").replaceChildren(headRow);

    const body = document.createDocumentFragment();
    rows.slice(0, PREVIEW_ROWS).forEach((row) => {
      const tr = document.createElement("tr");
      for (let index = 0; index < maxColumns; index += 1) {
        const td = document.createElement("td");
        const value = row[index];
        td.textContent = value instanceof Date
          ? value.toISOString().slice(0, 10)
          : value === null || value === undefined ? "" : String(value);
        tr.appendChild(td);
      }
      body.appendChild(tr);
    });
    $("batch-preview-table").querySelector("tbody").replaceChildren(body);

    $("batch-summary").textContent =
      `${rows.length.toLocaleString()} data rows; showing the first ${Math.min(rows.length, PREVIEW_ROWS)}.`;

    if (rows.length > MAX_ROWS) {
      showMessage(
        $("batch-message"),
        `This worksheet has ${rows.length.toLocaleString()} rows. The current limit is ${MAX_ROWS.toLocaleString()}.`,
        "error"
      );
      $("batch-convert").disabled = true;
    } else {
      showMessage($("batch-message"), "");
      $("batch-convert").disabled = rows.length === 0;
    }
    $("batch-results").classList.add("is-hidden");
  }

  $("batch-sheet").addEventListener("change", loadSelectedSheet);
  $("batch-header-row").addEventListener("change", () => {
    populateColumnSelectors();
    renderPreview();
  });
  $("batch-x-column").addEventListener("change", () => $("batch-results").classList.add("is-hidden"));
  $("batch-y-column").addEventListener("change", () => $("batch-results").classList.add("is-hidden"));

  function uniqueHeader(existing, desired) {
    let name = desired;
    let counter = 2;
    const normalized = new Set(existing.map((value) => String(value ?? "").toLowerCase()));
    while (normalized.has(name.toLowerCase())) {
      name = `${desired}_${counter}`;
      counter += 1;
    }
    existing.push(name);
    return name;
  }

  function nextFrame() {
    return new Promise((resolve) => requestAnimationFrame(resolve));
  }

  $("batch-convert").addEventListener("click", async () => {
    $("batch-results").classList.add("is-hidden");
    showMessage($("batch-message"), "");

    const headerIndex = Number($("batch-header-row").value);
    const header = [...(sheetMatrix[headerIndex] || [])];
    const dataRows = sheetMatrix.slice(headerIndex + 1).filter((row) =>
      row.some((value) => value !== null && value !== undefined && String(value).trim() !== "")
    );

    if (!dataRows.length) {
      showMessage($("batch-message"), "No data rows were found.", "error");
      return;
    }
    if (dataRows.length > MAX_ROWS) {
      showMessage($("batch-message"), `The maximum is ${MAX_ROWS.toLocaleString()} rows.`, "error");
      return;
    }

    const xIndex = Number($("batch-x-column").value);
    const yIndex = Number($("batch-y-column").value);
    if (xIndex === yIndex) {
      showMessage($("batch-message"), "Select two different columns for X and Y.", "error");
      return;
    }

    const outputHeaders = [...header];
    const added = {
      x: uniqueHeader(outputHeaders, "Converted_X"),
      y: uniqueHeader(outputHeaders, "Converted_Y"),
      source: uniqueHeader(outputHeaders, "Source_CRS"),
      target: uniqueHeader(outputHeaders, "Target_CRS"),
      zone: uniqueHeader(outputHeaders, "Target_UTM_Zone"),
      hemisphere: uniqueHeader(outputHeaders, "Target_UTM_Hemisphere"),
      status: uniqueHeader(outputHeaders, "Conversion_Status"),
      message: uniqueHeader(outputHeaders, "Conversion_Message")
    };

    const outputRows = [outputHeaders];
    const errors = [[
      "Excel_Row", "Original_X", "Original_Y",
      "Source_CRS", "Target_CRS", "Error_Message"
    ]];

    let successCount = 0;
    let errorCount = 0;

    $("batch-progress-wrap").classList.remove("is-hidden");
    $("batch-progress").value = 0;
    $("batch-convert").disabled = true;

    for (let index = 0; index < dataRows.length; index += 1) {
      const original = [...dataRows[index]];
      while (original.length < header.length) original.push(null);

      const resultCells = new Array(8).fill("");
      try {
        const conversion = convertCoordinate(batchControls, original[xIndex], original[yIndex]);
        resultCells[0] = conversion.targetGeographic ? conversion.x : Number(conversion.x.toFixed(3));
        resultCells[1] = conversion.targetGeographic ? conversion.y : Number(conversion.y.toFixed(3));
        resultCells[2] = conversion.sourceLabel;
        resultCells[3] = conversion.targetLabel;
        resultCells[4] = conversion.targetZone;
        resultCells[5] = conversion.targetHemisphere;
        resultCells[6] = "OK";
        resultCells[7] = "";
        successCount += 1;
      } catch (error) {
        let sourceLabel = batchControls.sourceCrs.options[batchControls.sourceCrs.selectedIndex].text;
        let targetLabel = batchControls.targetCrs.options[batchControls.targetCrs.selectedIndex].text;
        resultCells[2] = sourceLabel;
        resultCells[3] = targetLabel;
        resultCells[6] = "ERROR";
        resultCells[7] = error.message || "Conversion failed.";
        errors.push([
          headerIndex + index + 2,
          original[xIndex],
          original[yIndex],
          sourceLabel,
          targetLabel,
          resultCells[7]
        ]);
        errorCount += 1;
      }

      outputRows.push(original.concat(resultCells));

      if (index % 200 === 0 || index === dataRows.length - 1) {
        const percent = Math.round(((index + 1) / dataRows.length) * 100);
        $("batch-progress").value = percent;
        $("batch-progress-text").textContent =
          `${percent}% — ${(index + 1).toLocaleString()} of ${dataRows.length.toLocaleString()}`;
        await nextFrame();
      }
    }

    outputMatrix = outputRows;
    errorMatrix = errors.length > 1 ? errors : null;

    $("batch-total").textContent = dataRows.length.toLocaleString();
    $("batch-success").textContent = successCount.toLocaleString();
    $("batch-errors").textContent = errorCount.toLocaleString();
    $("download-errors").classList.toggle("is-hidden", !errorMatrix);
    $("batch-results").classList.remove("is-hidden");
    $("batch-convert").disabled = false;

    showMessage(
      $("batch-message"),
      `Completed: ${successCount.toLocaleString()} converted, ${errorCount.toLocaleString()} errors.`,
      errorCount ? "error" : "success"
    );
  });

  function createWorkbookFromMatrix(matrix, sheetName) {
    const worksheet = XLSX.utils.aoa_to_sheet(matrix);
    worksheet["!freeze"] = { xSplit: 0, ySplit: 1 };

    const widths = matrix[0].map((header, index) => {
      let width = Math.max(10, String(header ?? "").length + 2);
      for (const row of matrix.slice(1, 101)) {
        const value = row[index];
        if (value !== null && value !== undefined) {
          width = Math.max(width, Math.min(35, String(value).length + 2));
        }
      }
      return { wch: Math.min(width, 35) };
    });
    worksheet["!cols"] = widths;

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, worksheet, sheetName);
    return wb;
  }

  $("download-results").addEventListener("click", () => {
    if (!outputMatrix) return;
    const wb = createWorkbookFromMatrix(outputMatrix, "Converted Coordinates");
    XLSX.writeFile(wb, `${inputFileBaseName}_converted.xlsx`, {
      compression: true,
      bookType: "xlsx"
    });
  });

  $("download-errors").addEventListener("click", () => {
    if (!errorMatrix) return;
    const wb = createWorkbookFromMatrix(errorMatrix, "Conversion Errors");
    XLSX.writeFile(wb, `${inputFileBaseName}_errors.xlsx`, {
      compression: true,
      bookType: "xlsx"
    });
  });

  $("download-template").addEventListener("click", () => {
    const template = [
      ["ID", "X", "Y", "Name"],
      [1, 35.2, 32.5, "Example WGS 84 point"],
      [2, 34.7818, 32.0853, "Example WGS 84 point"]
    ];
    const wb = createWorkbookFromMatrix(template, "Coordinates");
    XLSX.writeFile(wb, "coordinate_conversion_template.xlsx", {
      compression: true,
      bookType: "xlsx"
    });
  });
});
